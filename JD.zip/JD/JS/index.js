
(function(){
    //点击closetip隐藏topbanner
    var closeTopBanner=document.getElementsByClassName("closetip");
    var topBannerBox=document.getElementsByClassName("topbanner");
    closeTopBanner[0].onclick=function(){
        topBannerBox[0].classList.add("hide");
    };
    //选择自己所在的城市
    var opositioning=document.getElementById("positioning");
    var city_list=document.getElementById("city-list");
    var liarr=city_list.getElementsByTagName("li");
    var aarr=city_list.getElementsByTagName("a");
    aarr[0].style.color="#fff";
    aarr[0].style.backgroundColor="#f10215";
    for(var i= 0;i<liarr.length;i++){
        liarr[i].index=i;
        liarr[i].onclick=function(){
            opositioning.innerHTML=this.innerHTML;
            for(var j=0;j<aarr.length;j++){
                aarr[j].style.color="";
                aarr[j].style.backgroundColor="";
            }
            aarr[this.index].style.color="#fff";
            aarr[this.index].style.backgroundColor="#f10215";
        }
    }
    //主内容1侧边菜单栏
    $(function(){
        $(".sidebar").mouseenter(function(){
            $(".memulist-content").removeClass("hide");
        });
        $(".sidebar-memu>ul>li").mouseenter(function(){
            $(".memulist-content>div").hide();
            $(".memulist-content>div").eq(($(this).index())).show();
        });
        $(".sidebar").mouseleave(function(){
            $(".memulist-content").addClass("hide");
        });
    });
    //搜索框特效
    var search_box=document.getElementById("search-box");
    var searchBoxContent=search_box.value;
    search_box.onfocus=function(){

        if(this.value===searchBoxContent){
            search_box.value="";
        }
    }
    search_box.onblur=function(){
        if(this.value===""){
            search_box.value=searchBoxContent;
        }
    }
})();

(function(){
    //主内容1轮播图
    var wrap = document.querySelector(".wrap");
    var next = document.querySelector(".arrow_right");
    var prev = document.querySelector(".arrow_left");
    var ptnb = document.querySelector(".pictureNumber");
    var listarr=ptnb.getElementsByTagName("li");
    var spanarr=ptnb.getElementsByTagName("span");
    var bool = false;
    var count=0;
    var nub=0;
    //手动播放
    next.onclick = function () {
        next_pic();
    }
    prev.onclick = function () {
        prev_pic();
    }
    function next_pic () {
        var newLeft;
        if(wrap.style.left==="-5310px"){
            newLeft=-1180;
        }else{
            newLeft = parseInt(wrap.style.left)-590;
        }
        wrap.style.left = newLeft + "px";
        nub+=1;
        if (nub > 7) {
            nub = 0;
        }
        tipshow();
    }
    function prev_pic () {
        var newLeft;
        if(wrap.style.left==="0px"){
            newLeft=-4130;
        }else{
            newLeft = parseInt(wrap.style.left)+590;
        }
        wrap.style.left = newLeft + "px";
        nub-=1;
        if (nub < 0) {
            nub = 7;
        }
        tipshow();
    }
    //自动播放
    var timer = null;
    function autoPlay () {
        timer = setInterval(function () {
            next_pic();
        },2000);
    }
    autoPlay();
    //手动自动切换
    var fastNavSilder = document.querySelector(".fast-nav-silder");
    fastNavSilder.onmouseenter = function () {
        clearInterval(timer);
    }
    fastNavSilder.onmouseleave = function () {
        autoPlay();
    }


    spanarr[0].style.backgroundColor="rgba(255,255,255,1)";
    listarr[0].style.backgroundColor="rgba(255,255,255,0.3)";

    for(var b=0;b<listarr.length;b++){
        listarr[b].index=b;
        listarr[b].onmouseover=function(){
            clearInterval(timer);
            for(var k=0;k<listarr.length;k++){
                listarr[k].style.backgroundColor="";
                spanarr[k].style.backgroundColor="";
            }
            listarr[this.index].style.backgroundColor="rgba(255,255,255,0.3)";
            spanarr[this.index].style.backgroundColor="rgba(255,255,255,1)";
            wrap.style.left= -590 * (this.index+1) + "px";
            nub=this.index;
        }
    }
    function tipshow(){
        for(var i=0;i<listarr.length;i++){
            listarr[i].style.backgroundColor="";
            spanarr[i].style.backgroundColor="";
        }
        listarr[nub].style.backgroundColor="rgba(255,255,255,0.3)";
        spanarr[nub].style.backgroundColor="rgba(255,255,255,1)";
    }
})();

(function(){
    //主内容2倒计时
    var Ohour=document.getElementById("cd-hour");
    var Ominute=document.getElementById("cd-minute");
    var Osecond=document.getElementById("cd-second");
    /*定义设定的时间*/
    var future = new Date("2018/04/26 16:36:10");
    var timer = setInterval(fn,1);
    function fn(){
        ///*定义现在的时间*/
        var nowtime = new Date();
        var timeSum = future.getTime() - nowtime.getTime();
        /*天数*/
        var day = parseInt(timeSum/1000/60/60/24);
        /*小时*/
        var hour = parseInt(timeSum/1000/60/60%24);
        /*分钟*/
        var minu = parseInt(timeSum/1000/60%60);
        /*秒*/
        var sec = parseInt(timeSum/1000%60);
        /*毫秒*/
        var millsec = parseInt(timeSum%1000);

        day=day<10?"0"+day:day;
        hour=hour<10?"0"+hour:hour;
        minu=minu<10?"0"+minu:minu;
        sec=sec<10?"0"+sec:sec;
        if(millsec<10){
            millsec="00"+millsec;
        }else if(millsec<100){
            millsec="0"+millsec;
        }
        if(timeSum<0){
            future = new Date(new Date().getTime() + 7200000);
            return future
        }
        Ohour.innerHTML=hour;
        Ominute.innerHTML=minu;
        Osecond.innerHTML=sec;
        return timeSum;
    }
})();

(function(){
    //主内容2内容切换
    var Oarrow=document.querySelector('.scroll-img-1>.arrow');
    var turnImg=Oarrow.getElementsByTagName("a");
    var Olist=document.querySelectorAll('.img-item>li');
    var shuzi=0;
    turnImg[1].onclick=function(){
        shuzi++;
        if(shuzi>Olist.length-1){
            shuzi=0;
        }
        for(var i=0;i<Olist.length;i++){
            Olist[i].classList.add("hide");
        }
        Olist[shuzi].classList.remove("hide");
    };
    turnImg[0].onclick=function(){
        shuzi--;
        if(shuzi<0){
            shuzi=Olist.length-1;
        }
        for(var i=0;i<Olist.length;i++){
            Olist[i].classList.add("hide");
        }
        Olist[shuzi].classList.remove("hide");
    };
})();

(function() {
    //主内容2轮播图
    var all = document.querySelector(".scroll-img-2");
    var screen = document.querySelector(".scroll-img-2-wrap");
    var ul = screen.children[0];
    var lis = ul.children;
    var ol = screen.children[1];
    var firstLi = ul.children[0];
    var key = 0;
    var square = 0;
    function animate(obj,target) {
        clearInterval(obj.timer);

        var speed = obj.offsetLeft < target ? 15 : -15;

        obj.timer = setInterval(function () {
            var result = target - obj.offsetLeft;

            obj.style.left = obj.offsetLeft + speed + "px";
            console.log(speed);
            if(Math.abs(result) <= 10 ){
                clearInterval(obj.timer);
                obj.style.left = target + "px";
            }

        },10);
    }
    //一、克隆图片加入到ul中
    var newLi = firstLi.cloneNode(true);
    ul.appendChild(newLi);
    ////二、动态生成li。
    for(var i=0;i<lis.length-1;i++){
        var newli = document.createElement("li");
        newli.innerHTML = i+1;
        ol.appendChild(newli);
    }
    ////三、焦点悬停动画。
    ////1、小方块的颜色切换(排他思想)
    var olLis = ol.children;
    olLis[0].className = "current";
    for(var i=0;i<olLis.length;i++){
        olLis[i].index = i;
        olLis[i].onmouseover = function () {
            for(var j=0;j<olLis.length;j++){
                olLis[j].className = "";
            }
            this.className = "current";

            key = square = this.index;
            //2、图片的切换
            animate(ul,-this.index*lis[0].offsetWidth);
        }
    }
    //四、加定时器
    var timer = null;
    timer = setInterval(autoPlay,3000);

    function animate(obj,target) {
        clearInterval(obj.timer);

        var speed = obj.offsetLeft < target ? 15 : -15;

        obj.timer = setInterval(function () {
            var result = target - obj.offsetLeft;

            obj.style.left = obj.offsetLeft + speed + "px";
            if(Math.abs(result) <= 10 ){
                clearInterval(obj.timer);
                obj.style.left = target + "px";
            }

        },10);
    }

    function autoPlay(){
        key++;
        square++;
        if(key>2){
            key=1;
            ul.style.left = 0+ 'px';
        }
        animate(ul,-key*lis[0].offsetWidth);

        square = square > olLis.length-1? 0:square;
        for(var i=0;i<olLis.length;i++){
            olLis[i].className = "";
        }
        olLis[square].className = "current";

    }
})();
//主内容3排行榜
(function(){
    var mainContent=document.querySelector(".main-content-3");
    var contentboxlist=mainContent.querySelectorAll(".contentbox");
    var nav=document.querySelector(".content-3-nav");
    var list=nav.querySelectorAll("li");
    var wrap=contentboxlist[0].querySelectorAll(".content-wrap");
    for(var i=0;i<list.length;i++){
        list[i].index=i;
        list[i].onmouseenter=function(){
            var contentBoxList=$('.content-box');
            for(var i=0;i<contentBoxList.length;i++){
                contentBoxList[i].style.left="0";
            }
            for(var j=0;j<wrap.length;j++){
            wrap[j].classList.add("hide");
            wrap[this.index].classList.remove("hide");
            }
        }
    }
    $(function(){
        $('.contentbox:nth-child(1) .focus>li').eq(0).css("background-color"," #fdd9dd").children().eq(0).css({"background-color":" #eb3436","border-color":"#eb3436"});
        $('.contentbox:nth-child(3) .focus>li').eq(0).css("background-color"," #fdd9dd").children().eq(0).css({"background-color":" #eb3436","border-color":"#eb3436"});

        function focalSwitch(obj,box){
            obj.css("background-color"," #fdd9dd").siblings("li").css("background-color","");
            obj.children().css({"background-color":" #eb3436","border-color":"#eb3436"}).parent().siblings("li").children().css({"background-color":"#fff","border-color":"#b9beba"});
            var contentBoxList=box;
            for(var i=0;i<contentBoxList.length;i++){
                if(obj.index()==0){
                    contentBoxList[i].style.left="0";
                }
                else{
                    contentBoxList[i].style.left="-350px";
                }
            }
        }
        $('.contentbox:nth-child(1) .focus>li').mouseenter(function(){
            focalSwitch($(this),$('.contentbox:nth-child(1) .content-box'));
        });
        $('.contentbox:nth-child(3) .focus>li').mouseenter(function(){
            focalSwitch($(this),$('.contentbox:nth-child(3) .main-box'));
        });
    });
})();
(function(){
    var mainContent=document.querySelector(".main-content-3");
    var contentboxlist=mainContent.querySelectorAll(".contentbox");
    var all = contentboxlist[1].querySelector(".content-3-main");
    var screen = contentboxlist[1].querySelector(".main-wrap");
    var ul = screen.children[0];
    var lis = ul.children;
    var ol = all.children[2];
    var firstLi = ul.children[0];
    var key = 0;
    var square = 0;
    var arr = contentboxlist[1].querySelector(".arrow");
    var arrLeft = arr.children[0];
    var arrRight = arr.children[1];
//  加入到图片最后
    var newLi = firstLi.cloneNode(true);
    ul.appendChild(newLi);
//  焦点创建
    for(var j=0;j<lis.length-1;j++){
      var newli = document.createElement("li");
      var newspan=document.createElement("span");
      ol.appendChild(newli);
      newli.appendChild(newspan);
  }
//焦点悬停动画。
//  当前焦点的样式设置
    var olLis=ol.children;
    olLis[0].style.backgroundColor="#fdd9dd";
    olLis[0].children[0].style.backgroundColor="#eb3436";
    olLis[0].children[0].style.borderColor="#eb3436";
//  for循环遍历焦点并设置焦点悬停动画
    for(var i=0;i<olLis.length;i++){
        olLis[i].index = i;
        olLis[i].onmouseover = function () {
            for(var j=0;j<olLis.length;j++){
                olLis[j].style.backgroundColor="";
                olLis[j].children[0].style.backgroundColor="#fff";
                olLis[j].children[0].style.borderColor="#b9beba";
            }
            this.style.backgroundColor="#fdd9dd";
            this.children[0].style.backgroundColor="#eb3436";
            this.children[0].style.borderColor="#eb3436";
            key = square = this.index;
//  调用图片的切换函数
            animate(ul,-this.index*lis[0].offsetWidth);
        }
    }
//  图片的切换函数【两个参数】
    function animate(obj,target) {
        clearInterval(obj.timer);

        var speed = obj.offsetLeft < target ? 15 : -15;

        obj.timer = setInterval(function () {
            var result = target - obj.offsetLeft;

            obj.style.left = obj.offsetLeft + speed + "px";

            if(Math.abs(result) <= 10 ){
                clearInterval(obj.timer);
                obj.style.left = target + "px";
            }
        },10);
    }

    var timer = null;
    timer = setInterval(autoPlay,2000);

    function autoPlay(){
        key++;
        square++;
        if(key>3){
            key=1;
            ul.style.left = 0+ 'px';
        }
        animate(ul,-key*lis[0].offsetWidth);

        square = square > olLis.length-1? 0:square;
        for(var i=0;i<olLis.length;i++){
            olLis[i].style.backgroundColor="";
            olLis[i].children[0].style.backgroundColor="#fff";
            olLis[i].children[0].style.borderColor="#b9beba";
        }
        olLis[square].style.backgroundColor="#fdd9dd";
        olLis[square].children[0].style.backgroundColor="#eb3436";
        olLis[square].children[0].style.borderColor="#eb3436";
    }

    all.onmouseover = function () {
        //arr.style.display = "block";
        clearInterval(timer);
    }
    all.onmouseout = function () {
        //arr.style.display = "none";
        timer = setInterval(autoPlay,3000);
    }

    arrRight.onclick = function () {
        autoPlay();
    }

    arrLeft.onclick = function () {
        key--;
        square--;
        if(key<0){
            key=2;
            ul.style.left = -3*lis[0].offsetWidth+ 'px';
        }
        animate(ul,-key*lis[0].offsetWidth);

        square = square <0 ? 2:square;
        for(var i=0;i<olLis.length;i++){
            olLis[i].style.backgroundColor="";
            olLis[i].children[0].style.backgroundColor="#fff";
            olLis[i].children[0].style.borderColor="#b9beba";
        }
        olLis[square].style.backgroundColor="#fdd9dd";
        olLis[square].children[0].style.backgroundColor="#eb3436";
        olLis[square].children[0].style.borderColor="#eb3436";
        console.log(key+"  " + square);
    }

})();
