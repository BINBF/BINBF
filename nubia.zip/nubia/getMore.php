<?php 
	echo file_get_contents('data/info.json');
 ?>