$(document).ready(function(){
//获取banner的高度
    var bannerH=$("#form-control").offset().top;
//滚动事件
    $(window).scroll(function(){
//滚动的高度
        var scrollTop=$(this).scrollTop();
//判断bannerH大于或者等于scrollTop高度
        if(scrollTop >= bannerH ){
        $(".header-nav").css("background-color","white");
        $(".nav > li>.huaban").css("background","url(img/logo.svg) 0 0 no-repeat");
        $(".nav > li:nth-child(2) > a").css("color","#c90000");
        $(".nav > li> a").css({"color":"#444","backgroundCcolor":"transparent"});
        $(" .navbar-nav > li:nth-child(5) > a").css("background","url(img/menu_sprite.svg) 0 -248px no-repeat");
        $(".form-group-top").removeClass("hide");

        }else{
            $(".header-nav").css("background-color","transparent");
            $(".nav > li>.huaban").css("background","url(img/logo_wt.svg) 0 0 no-repeat");
            $(".nav > li:nth-child(2) > a").css({"color":" rgba(255,255,255,.85)","backgroundCcolor":"transparent"});
            $(".nav > li> a").css({"color":" rgba(255,255,255,.85)","backgroundCcolor":"transparent"});
            $(" .navbar-nav > li:nth-child(5) > a").css("background","url(img/menu_sprite.svg) -50px -558px no-repeat");
            $(".form-group-top").addClass("hide");
        }
    })
})

$(function() {
    $(".add-more").click(function() {
        $.ajax({
            url: 'getMore.php',
            type: 'get',
            success: function(data) {
                var oneObj = JSON.parse(data);
                // 调用模板引擎的方法 填充数据
                var resultStr =template('template',oneObj);
                $('.recommend-container').append(resultStr);
            }
        })
    })
})